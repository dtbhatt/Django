from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from django.db.models import Count, Sum

from .models import User, Poke

def index(request):
    return render(request, 'logreg/index.html')

def success(request):
    # Poke.objects.all().delete()
    if "id" in request.session:
        context = {
            "user":User.objects.get(id=request.session["id"]),
            "users":User.objects.all().annotate(totaled=Sum("poked_user__counter")).exclude(id=request.session["id"]),
            "poked" : Poke.objects.all().exclude(id=request.session['id']),
            "user_poke_count" : Poke.objects.all().filter(poked=request.session['id']),
            # "list_of_users" : Poke.objects.filter(poked=request.session["id"]).exclude(id=request.session["id"]),
            "youPoked" : Poke.objects.all().filter(poked=request.session['id'])
        }
        print success
        return render(request, 'logreg/success.html', context)
    else:
        messages.add_message(request, messages.ERROR, "Must be a Registered User!")
        return redirect('/')

def login(request):
    res = User.objects.validlogin(request.POST)
    if res["status"]:
        # set id in session
        request.session["id"] = res["data"].id
        return redirect('/success')
    
    for error in res["data"]:
        messages.error(request, error) 

    return redirect('/')


def register(request):
    res = User.objects.validregister(request.POST)
    if res["status"]:
        # set id in session
        request.session["id"] = res["data"].id
        return redirect('/success')
    
    for error in res["data"]:
        messages.error(request, error) 

    return redirect('/')

def newpoke(request, userId):
    poker = User.objects.get(id=request.session['id'])
    poked = User.objects.get(id=userId)
    
    if len(Poke.objects.filter(poker=poker, poked=poked)) > 0:
        numPokes = Poke.objects.get(poker=poker, poked=poked)
        numPokes.counter = int(numPokes.counter) + 1
        numPokes.save()
    else:
        poke = Poke()
        poke.poker = poker
        poke.poked = poked
        poke.counter = 1
        poke.save() 
    return redirect('/success')

def logout(request):
    request.session.pop('id')
    return redirect('/')

# Create your views here.
